﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JUEGO_DEFINITIVO
{
    public class RepositorioSql
    {
    }
}
