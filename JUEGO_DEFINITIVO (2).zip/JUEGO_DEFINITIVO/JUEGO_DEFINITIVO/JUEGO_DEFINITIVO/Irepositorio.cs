﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;

namespace JUEGO_DEFINITIVO
{
    //contrato de acceso a datos: ahora lo implementa RepositorioArchivos, despues puede ser RepositorioSql
    public interface IRepositorio
    {
        TiposAsteroides[] ObtenerTiposAsteroides();
        TipoPowerUp[] ObtenerTiposPowerUp();
        Sesion[] ObtenerSesiones();
        void GuardarSesion(Sesion s);
        void RegistrarEvento(EventoJuego e);
    }
}
