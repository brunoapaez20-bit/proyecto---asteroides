﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace JUEGO_DEFINITIVO
{
    public class PowerUp
    {
        public Vector2 Pos;
        public int Tipo;           //id del TipoPowerUp
        public bool Activo = true;
    }
}
