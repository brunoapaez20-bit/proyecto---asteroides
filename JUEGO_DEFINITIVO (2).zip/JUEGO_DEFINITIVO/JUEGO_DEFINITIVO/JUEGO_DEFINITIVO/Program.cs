﻿using JUEGO_DEFINITIVO;
using Microsoft.Xna.Framework;

using var game = new Game1();
game.Run();