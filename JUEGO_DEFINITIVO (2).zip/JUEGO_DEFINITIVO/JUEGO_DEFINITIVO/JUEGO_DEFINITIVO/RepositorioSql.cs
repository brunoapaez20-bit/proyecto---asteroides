﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Globalization;
using System.Linq;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.Xna.Framework;

namespace JUEGO_DEFINITIVO;

//================= CLASES DE LAS TABLAS =================
[Table("jugadores")]
public class JugadorDb
{
    [Key] public int id { get; set; }
    public string nombre { get; set; } = "";
    public string email { get; set; } = "";
    public DateTime fecha_registro { get; set; }
}

[Table("partidas")]
public class PartidaDb
{
    [Key] public int id { get; set; }
    public int jugador_id { get; set; }
    public DateTime inicio { get; set; }
    public DateTime? fin { get; set; }
    public int tiempo_supervivencia { get; set; }
    public string dificultad_inicial { get; set; } = "";
    public int puntos { get; set; }
    public int esquivados { get; set; }
    public int cerca { get; set; }
}

[Table("tiposasteroides")]
public class TipoAsteroideDb
{
    [Key] public int id { get; set; }
    [Column("tamaño")] public string tamanio { get; set; } = "";
    public decimal velocidad_base { get; set; }
    public string sprite { get; set; } = "";
    public int puntos_evasion { get; set; }
}

[Table("mejoras")]
public class MejoraDb
{
    [Key] public int id { get; set; }
    public string nombre { get; set; } = "";
    public string efecto { get; set; } = "";
    public int duracion_base { get; set; }
    public decimal probabilidad_spawn { get; set; }
}

public class AppDbContext : DbContext
{
    public DbSet<JugadorDb> jugadores => Set<JugadorDb>();
    public DbSet<PartidaDb> partidas => Set<PartidaDb>();
    public DbSet<TipoAsteroideDb> tiposasteroides => Set<TipoAsteroideDb>();
    public DbSet<MejoraDb> mejoras => Set<MejoraDb>();

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        string connectionString = "Server=localhost;Port=3306;Database=juego_asteroides;Uid=root;pwd=;";
        var serverVersion = ServerVersion.AutoDetect(connectionString);
        optionsBuilder.UseMySql(connectionString, serverVersion);
    }
}

// ================= REPOSITORIO =================
public class RepositorioSql : IRepositorio
{
    // Si MySQL esta apagado, se usan los datos de prueba de RepositorioArchivos
    readonly RepositorioArchivos _respaldo = new RepositorioArchivos();

    public TiposAsteroides[] ObtenerTiposAsteroides()
    {
        try
        {
            using var db = new AppDbContext();
            return db.tiposasteroides.AsNoTracking().ToList()
                .Select(t => new TiposAsteroides
                {
                    Id = t.id,
                    Tamano = SinTildes(t.tamanio),
                    VelocidadBase = (float)t.velocidad_base,
                    PuntosEvasion = t.puntos_evasion
                }).ToArray();
        }
        catch (Exception ex)
        {
            Archivos.Log("ERROR BD tipos asteroides: " + ex.Message);
            return _respaldo.ObtenerTiposAsteroides();
        }
    }

    public TipoPowerUp[] ObtenerTiposPowerUp()
    {
        try
        {
            using var db = new AppDbContext();
            return db.mejoras.AsNoTracking().ToList()
                .Select(m => new TipoPowerUp
                {
                    Id = m.id,
                    Nombre = SinTildes(m.nombre),
                    Duracion = m.duracion_base,
                    Letra = LetraDe(m.id),
                    Color = ColorDe(m.id)
                }).ToArray();
        }
        catch (Exception ex)
        {
            Archivos.Log("ERROR BD power-ups: " + ex.Message);
            throw;
        }
    }

    public Sesion[] ObtenerSesiones()
    {
        try
        {
            using var db = new AppDbContext();
            var datos = (from p in db.partidas.AsNoTracking()
                         join j in db.jugadores.AsNoTracking() on p.jugador_id equals j.id
                         select new
                         {
                             j.nombre,
                             p.tiempo_supervivencia,
                             p.esquivados,
                             p.cerca,
                             p.puntos,
                             p.inicio,
                             p.fin
                         }).ToList();

            return datos.Select(d => new Sesion
            {
                Jugador = d.nombre,
                TiempoSupervivencia = d.tiempo_supervivencia,
                Esquivados = d.esquivados,
                Cerca = d.cerca,
                Puntos = d.puntos,
                Fecha = (d.fin ?? d.inicio).ToString("yyyy-MM-dd HH:mm")
            }).ToArray();
        }
        catch (Exception ex)
        {
            Archivos.Log("ERROR BD sesiones: " + ex.Message);
            throw;
        }
    }

    public void GuardarSesion(Sesion s)
    {
        try
        {
            using var db = new AppDbContext();
            string nombre = s.Jugador.Length > 50 ? s.Jugador.Substring(0, 50) : s.Jugador;

            //busca al jugador; si no existe, lo crea (el email es obligatorio en la tabla)
            JugadorDb jugador = db.jugadores.FirstOrDefault(j => j.nombre == nombre);
            if (jugador == null)
            {
                jugador = new JugadorDb
                {
                    nombre = nombre,
                    email = nombre.ToLower().Replace(' ', '_') + "@asteroiddodge.local",
                    fecha_registro = DateTime.Now
                };
                db.jugadores.Add(jugador);
                db.SaveChanges();   //asi jugador.id ya tiene valor
            }

            db.partidas.Add(new PartidaDb
            {
                jugador_id = jugador.id,
                inicio = DateTime.Now.AddSeconds(-s.TiempoSupervivencia),
                fin = DateTime.Now,
                tiempo_supervivencia = s.TiempoSupervivencia,
                dificultad_inicial = "Normal",
                puntos = s.Puntos,
                esquivados = s.Esquivados,
                cerca = s.Cerca
            });
            db.SaveChanges();
        }
        catch (Exception ex)
        {
            Archivos.Log("ERROR BD guardar sesion: " + ex.Message);
        }
    }

    //por ahora los eventos siguen yendo al log.txt
    public void RegistrarEvento(EventoJuego e)
    {
        Archivos.Log(e.Tipo + ";t=" + e.Tiempo.ToString("0.0") + ";asteroide=" + e.AsteroideTipo +
                     ";puntos=" + e.Puntos + ";dist=" + e.Distancia.ToString("0.0"));
    }

    //---- auxiliares ----
    //la BD no guarda letra ni color de los power-ups: se asignan por id (tabla mejoras)
    static string LetraDe(int id)
    {
        return id == 1 ? "E" : id == 2 ? "L" : id == 3 ? "x2" : "B";
    }

    static Color ColorDe(int id)
    {
        return id == 1 ? new Color(255, 216, 77)
             : id == 2 ? new Color(92, 225, 255)
             : id == 3 ? new Color(125, 255, 154)
             : new Color(255, 107, 139);
    }

    //la fuente del juego solo dibuja ASCII: quita tildes y enie
    static string SinTildes(string s)
    {
        var sb = new StringBuilder();
        foreach (char c in s.Normalize(NormalizationForm.FormD))
            if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                sb.Append(c);
        return sb.ToString();
    }
}