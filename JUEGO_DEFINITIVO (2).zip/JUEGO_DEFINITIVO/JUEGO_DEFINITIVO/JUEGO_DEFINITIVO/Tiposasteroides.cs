﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JUEGO_DEFINITIVO
{
    public class TiposAsteroides
    {
        public int Id;
        public string Tamano;
        public float VelocidadBase;
        public int PuntosEvasion;
    }
}
