﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JUEGO_DEFINITIVO
{
    public class Sesion
    {
        public string Jugador;
        public int TiempoSupervivencia; //segundos
        public int Esquivados;
        public int Cerca;
        public int Puntos;
        public string Fecha;
    }
}
